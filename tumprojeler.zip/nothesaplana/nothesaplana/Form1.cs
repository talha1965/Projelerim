﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace nothesaplana
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int yazili1 = Convert.ToInt32(textBox1.Text);
                int yazili2 = Convert.ToInt32(textBox2.Text);
                int ortalama = 0;
                ortalama = (yazili1 + yazili2) / 2;
                if (yazili1 > 100)
                {
                    MessageBox.Show("Hatalı sayı girildi.");
                }
                if (yazili2 < 0)
                {
                    MessageBox.Show("Hatalı sayı girildi.");
                }
                if (ortalama > 50)
                {
                    MessageBox.Show("Öğrenci geçmiştir.  Ortalama:" + ortalama);
                }
                else if (ortalama < 50)
                {

                    MessageBox.Show("Öğrenci geçememiştir.  Ortalama:" + ortalama);


                }
                else if (ortalama == 50)
                {
                    MessageBox.Show("Öğrenci geçmiştir." + ortalama);
                }
            }
            catch (FormatException)
            {

                MessageBox.Show("Lütfen geçerli bir sayı giriniz." + "Hata");


            }
            catch (OverflowException)
            {
                MessageBox.Show("Girilen not çok büyük veya çok küçüktür." + "Hata");
            }

        }
    }
}

