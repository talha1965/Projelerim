namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int birinciSayi = Convert.ToInt32(textBox1.Text);
            int ikinciSayi = Convert.ToInt32(textBox2.Text);
            if (birinciSayi > ikinciSayi)
            {
                MessageBox.Show("birinci sayi ikinci sayidan b�y�kt�r");
            }
            else if (ikinciSayi > birinciSayi)
            {
                MessageBox.Show("ikinci sayi birinci sayidan b�y�kt�r.");
            }
            else if (birinciSayi == ikinciSayi)
            {
                MessageBox.Show("Say�lar e�ittir.");
            }
        }
    }
}
