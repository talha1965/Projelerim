﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sayi1, sayi2;
            Console.WriteLine("1. sayıyı giriniz.");
            sayi1=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("2. sayıyı giriniz.");
            sayi2= Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("İşaret seçiniz");
            int işaret = 0;
            işaret = Console.ReadKey().KeyChar;
            if(işaret=='+')
            {
               int toplama = 0;
               toplama=sayi1 + sayi2;
               Console.WriteLine(toplama);
               Console.WriteLine("Toplama işlemi gerçekleştirildi.");
               Console.ReadLine();
            }
            if (işaret == '-')
            {
                int çıkarma = 0;
                çıkarma = sayi1 - sayi2;
                Console.WriteLine(çıkarma);
                Console.WriteLine("Çıkarma işlemi gerçekleştirildi.");
                Console.ReadLine();

            }
            if (işaret== '/')
            {
                int bölme = 0;
                bölme = sayi1 / sayi2;
                Console.WriteLine(bölme);
                Console.WriteLine("Bölme işlemi gerçekleştirildi.");
                Console.ReadLine();
            }
            if (işaret== '*')
            {
                int çarpma = 0;
                çarpma = sayi1 * sayi2;
                Console.WriteLine(çarpma);
                Console.WriteLine("Çarpma işlemi gerçekleştirildi.");
                Console.ReadLine();
            }

        }
           
        }
        
    }

