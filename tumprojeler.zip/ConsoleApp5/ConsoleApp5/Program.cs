﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("İlk sayıyı girin: ");
        int sayi1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("İkinci sayıyı girin: ");
        int sayi2 = Convert.ToInt32(Console.ReadLine());

        int min = Math.Min(sayi1, sayi2);
        int max = Math.Max(sayi1, sayi2);

        int tekSayiSayisi = 0;

        for (int i = min; i <= max; i++)
        {
            if (i % 2 != 0)  
            {
                tekSayiSayisi++;
                Console.WriteLine(i);  
            }
        }

        Console.WriteLine($"Toplam {tekSayiSayisi} tek sayı var.");
        Console.ReadLine();
    }
}
