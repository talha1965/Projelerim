﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace NotTutmaUygulamasi
{
    public partial class Form1 : Form
    {
        private List<string> notlar;

        public Form1()
        {
            InitializeComponent();
            notlar = new List<string>();
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            string not = txtNot.Text.Trim();
            if (!string.IsNullOrEmpty(not))
            {
                notlar.Add(not);
                txtNot.Clear();
                ListeleNotlar();
            }
            else
            {
                MessageBox.Show("Not girmeyi unutmayın!");
            }
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            if (listBoxNotlar.SelectedItem != null)
            {
                notlar.Remove(listBoxNotlar.SelectedItem.ToString());
                ListeleNotlar();
            }
            else
            {
                MessageBox.Show("Silinecek notu seçin!");
            }
        }

        private void ListeleNotlar()
        {
            listBoxNotlar.Items.Clear();
            foreach (var not in notlar)
            {
                listBoxNotlar.Items.Add(not);
            }
        }
    }
}
