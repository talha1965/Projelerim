﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Bir sayı girin");
            int sayi1 = Convert.ToInt32(Console.ReadLine());
            int orijinalSayi = sayi1;
            int toplam = 0;
            int basamakSayisi = sayi1.ToString().Length; 

            for (int i = 0; sayi1 > 0; i++) 
            {
                int basamak = sayi1 % 10;  
                toplam = toplam + (int)Math.Pow(basamak, basamakSayisi); 
                sayi1 = sayi1 / 10;  
            }

            if (toplam == orijinalSayi)
            {
                Console.WriteLine(orijinalSayi + " bir Armstrong sayisidir.");
            }
            else
            {
                Console.WriteLine(orijinalSayi + " bir Armstrong sayisi değildir.");
            }

            Console.ReadLine();
        }
    
    }
}
