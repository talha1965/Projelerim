﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Varsayılan veriler
            var hocalar = new List<Hoca>
        {
            new Hoca("Ahmet Yılmaz", new List<string> { "Matematik", "Fizik" }),
            new Hoca("Elif Kaya", new List<string> { "Kimya", "Biyoloji" })
        };

            var ogrenciler = new List<Ogrenci>
        {
            new Ogrenci("Ali Vural", "10A", new List<string> { "Matematik", "Tarih", "Beden Eğitimi" }),
            new Ogrenci("Zeynep Kara", "10B", new List<string> { "Türkçe", "Fizik", "Müzik" })
        };

            var siniflar = new List<Sinif>
        {
            new Sinif("10A", new List<string> { "Matematik", "Fizik", "Tarih" }),
            new Sinif("10B", new List<string> { "Türkçe", "Kimya", "Biyoloji" })
        };

            // Kullanıcıdan giriş alınması
            Console.WriteLine("1- Hoca Bilgileri\n2- Öğrenci Bilgileri\n3- Sınıf Ders Programı");
            Console.Write("Seçiminizi yapın: ");
            int secim = int.Parse(Console.ReadLine());

            switch (secim)
            {
                case 1:
                    HocaBilgileriniYazdir(hocalar);
                    break;
                case 2:
                    OgrenciBilgileriniYazdir(ogrenciler);
                    break;
                case 3:
                    SinifBilgileriniYazdir(siniflar);
                    break;
                default:
                    Console.WriteLine("Geçersiz seçim.");
                    break;
            }
            Console.ReadLine();
        }

        static void HocaBilgileriniYazdir(List<Hoca> hocalar)
        {
            Console.WriteLine("\nHocalar ve Verdikleri Dersler:");
            foreach (var hoca in hocalar)
            {
                Console.WriteLine($"Hoca: {hoca.Ad} - Dersler: {string.Join(", ", hoca.Dersler)}");
            }
        }

        static void OgrenciBilgileriniYazdir(List<Ogrenci> ogrenciler)
        {
            Console.WriteLine("\nÖğrenciler ve Aldıkları Dersler:");
            foreach (var ogrenci in ogrenciler)
            {
                Console.WriteLine($"Ad: {ogrenci.Ad} - Sınıf: {ogrenci.Sinif} - Dersler: {string.Join(", ", ogrenci.Dersler)}");
            }
        }

        static void SinifBilgileriniYazdir(List<Sinif> siniflar)
        {
            Console.WriteLine("\nSınıflar ve Ders Programları:");
            foreach (var sinif in siniflar)
            {
                Console.WriteLine($"Sınıf: {sinif.Ad} - Dersler: {string.Join(", ", sinif.Dersler)}");
            }
        }
    }

    class Hoca
    {
        public string Ad { get; set; }
        public List<string> Dersler { get; set; }

        public Hoca(string ad, List<string> dersler)
        {
            Ad = ad;
            Dersler = dersler;
        }
    }

    class Ogrenci
    {
        public string Ad { get; set; }
        public string Sinif { get; set; }
        public List<string> Dersler { get; set; }

        public Ogrenci(string ad, string sinif, List<string> dersler)
        {
            Ad = ad;
            Sinif = sinif;
            Dersler = dersler;
        }
    }

    class Sinif
    {
        public string Ad { get; set; }
        public List<string> Dersler { get; set; }

        public Sinif(string ad, List<string> dersler)
        {
            Ad = ad;
            Dersler = dersler;
        }
    }
}

