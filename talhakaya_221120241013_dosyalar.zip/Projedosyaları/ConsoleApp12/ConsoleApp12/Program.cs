﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Console.Write("Birinci sayıyı girin: ");
            double sayi1 = double.Parse(Console.ReadLine());
            Console.Write("İkinci sayıyı girin: ");
            double sayi2 = double.Parse(Console.ReadLine());
            double geometrikOrtalama = Math.Sqrt(sayi1 * sayi2);
            Console.WriteLine($"\n{geometrikOrtalama:F2} (Geometrik Ortalama)");

            Console.ReadLine();
        }
    }
}
