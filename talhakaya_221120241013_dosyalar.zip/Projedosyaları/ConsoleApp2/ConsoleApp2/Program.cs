﻿using System;

namespace UcgenKontrol
{
    class Program
    {
        static void Main(string[] args)
        {
            // Kullanıcıdan a, b ve c değerlerini alıyoruz
            Console.WriteLine("a değerini girin: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("b değerini girin: ");
            int b = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("c değerini girin: ");
            int c = Convert.ToInt32(Console.ReadLine());

            // a ve b'yi topluyoruz, ardından bu toplamdan c'yi çıkarıyoruz
            int toplam = a + b;
            toplam = toplam - c;

            // Koşulları kontrol ediyoruz
            if (toplam < 100)
            {
                Console.WriteLine("Üçgen değil");
            }
            else if (toplam > 100)
            {
                Console.WriteLine("Üçgen");
            }

            // Program kapanmasın diye kullanıcının bir tuşa basmasını bekliyoruz
            Console.WriteLine("Devam etmek için bir tuşa basın...");
            Console.ReadKey();
        }
    }
}
