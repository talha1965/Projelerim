﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Üçgenin çevresini hesaplamak için kullanıcıdan 3 kenar bilgisi alıyoruz
            Console.Write("Üçgenin birinci kenar uzunluğunu girin: ");
            double kenar1 = double.Parse(Console.ReadLine());

            Console.Write("Üçgenin ikinci kenar uzunluğunu girin: ");
            double kenar2 = double.Parse(Console.ReadLine());

            Console.Write("Üçgenin üçüncü kenar uzunluğunu girin: ");
            double kenar3 = double.Parse(Console.ReadLine());

            // Üçgenin çevresini hesaplıyoruz
            double ucgenCevre = kenar1 + kenar2 + kenar3;

            // Karenin alanını hesaplamak için kullanıcıdan bir kenar bilgisi alıyoruz
            Console.Write("\nKarenin bir kenar uzunluğunu girin: ");
            double kareKenar = double.Parse(Console.ReadLine());

            // Karenin alanını hesaplıyoruz
            double kareAlan = kareKenar * kareKenar;

            // Sonuçları ekrana yazdırıyoruz
            Console.WriteLine("\n--- Sonuçlar ---");
            Console.WriteLine($"Üçgenin Çevresi: {ucgenCevre}");
            Console.WriteLine($"Karenin Alanı: {kareAlan}");
            Console.ReadLine();
        }
    }
}
