﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace ConsoleApp7
    {
        internal class Program
        {
            static void Main(string[] args)
            {
                Console.WriteLine("Bir sayı girin");
                int sayi1 =Convert.ToInt32(Console.ReadLine());
                int toplam = 0;
                for (int i = 1; i < sayi1; i++)
                {
                    if (sayi1 % i == 0)
                    {
                        toplam = toplam + i;

                    }
                }
                if (toplam == sayi1)
                {
                    Console.WriteLine(sayi1 + " mükemmel bir sayidir.");

                }
                else
                {
                    Console.WriteLine(sayi1 + " bir mükemmel sayi değildir.");
                }
                Console.ReadLine();
            }
        }
    }

