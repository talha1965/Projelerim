﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            {
                // Öğrenci bilgilerini al ve ortalamayı hesapla
                ogrenci();
            }
            
            static void ogrenci()
            {
                Console.Write("Öğrencinin Adı Soyadı: ");
                string adSoyad = Console.ReadLine();

                Console.Write("1. Sınav Notunu Girin: ");
                double sinav1 = double.Parse(Console.ReadLine());

                Console.Write("2. Sınav Notunu Girin: ");
                double sinav2 = double.Parse(Console.ReadLine());

                // Hesaplama metodunu çağır
                hesapla(adSoyad, sinav1, sinav2);
            }

            static void hesapla(string adSoyad, double sinav1, double sinav2)
            {
                double ortalama = (sinav1 + sinav2) / 2;

                Console.WriteLine("\n*** Öğrenci Bilgileri ***");
                Console.WriteLine($"Ad Soyad: {adSoyad}");
                Console.WriteLine($"1. Sınav Notu: {sinav1}");
                Console.WriteLine($"2. Sınav Notu: {sinav2}");
                Console.WriteLine($"Ortalama: {ortalama:F2}");
            }
        }
    }
}

