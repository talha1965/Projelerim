﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int sayi1;
            Console.WriteLine("Bir sayı giriniz.");
            sayi1 = Convert.ToInt32(Console.ReadLine());
            int toplam = 0;
;            for (int i = 0; i < sayi1; i++)
            {
                toplam = i + toplam;
            }
            Console.WriteLine(toplam);  

            Console.ReadLine();

        }
    }
}
