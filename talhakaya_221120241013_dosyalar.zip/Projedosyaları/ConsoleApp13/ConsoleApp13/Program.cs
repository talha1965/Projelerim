﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Adınızı ve Soyadınızı girin: ");
            string adSoyad = Console.ReadLine();
            Console.Write("Öğrenci numaranızı girin: ");
            string ogrenciNo = Console.ReadLine();
            Console.Write("Cep telefonunuzu girin: ");
            string cepTel = Console.ReadLine();
            Console.WriteLine("\n--- Öğrenci Bilgileri ---");
            Console.WriteLine($"Ad Soyad: {adSoyad}");
            Console.WriteLine($"Öğrenci No: {ogrenciNo}");
            Console.WriteLine($"Cep Telefonu: {cepTel}");
            Console.ReadLine();
        }
    }
}
